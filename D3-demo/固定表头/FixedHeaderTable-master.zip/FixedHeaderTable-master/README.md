#FixedHeaderTable

## Tests

[FixedHeaderTable Specification](spec/SpecRunner.html "Jasmine Specification")

## Examples

[Demo 1](examples/demo.html "FixedTableHeader Demo")
[Demo 1](examples/demo2.html "MinMaxCellDimensions Demo")

[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/stephen-james/fixedheadertable/trend.png)](https://bitdeli.com/free "Bitdeli Badge")

