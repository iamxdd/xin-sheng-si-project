const assert = require('power-assert');
const Model = require('../../dist/fixed_table.js').FixedTable.FixedTableModel;

describe('FixedTableModel', function() {
  it('Create Instance', function() {
  });
});