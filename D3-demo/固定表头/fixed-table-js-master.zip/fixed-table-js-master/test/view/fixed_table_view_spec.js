const assert = require('power-assert');
const View   = require('../../dist/fixed_table.js').FixedTable.FixedTableView;

describe('FixedTableView', function() {
  it('Create Instance', function() {
  });
});
