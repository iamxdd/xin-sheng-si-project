const assert    = require('power-assert');
const TableView = require('../../dist/fixed_table.js').FixedTable.TableView;

describe('TableView', function() {
  it('Create Instance', function() {
  });
});
