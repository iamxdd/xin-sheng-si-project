const assert  = require('power-assert');
const Utility = require('../../dist/fixed_table.js').FixedTable.Utility;

describe('Utility', function() {
  it('Create Instance', function() {
  });
});
