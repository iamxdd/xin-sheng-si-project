const assert = require('power-assert');
const Tbody  = require('../../dist/fixed_table.js').FixedTable.Tbody;

describe('Tbody', function() {
  it('Create Instance', function() {
  });
});